# CSCI 104 Student Repository

- **Name**: Tommy Bartecki
- **USC ID**: 4018782058
- **USC Email**: bartecki@usc.edu

 Code compiles with make or make hw4. An input file is taken in and parsed before being evaluated and outputting the correct results based on the input.