- **Name**: Tommy Bartecki
- **USC ID**: 4018782058
- **USC Email**: bartecki@usc.edu

Answers for problems 1-3 are contained in the hw3.txt file.

permutations.cpp produces all permutations of a given input string

cave.cpp produces the distance you are inside the cave after all moves

company.cpp simulates the merging and splitting of a certain number of students' comapanies