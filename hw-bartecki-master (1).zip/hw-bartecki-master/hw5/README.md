# CSCI 104 Student Repository

- **Name**: Tommy Bartecki
- **USC ID**: 4018782058
- **USC Email**: bartecki@usc.edu

 