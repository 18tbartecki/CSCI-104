# CSCI 104 Student Repository

- **Name**: Tommy Bartecki
- **USC ID**: 4018782058
- **USC Email**: bartecki@usc.edu


Each input file is taken in and parsed according to the rules for the assignment. For example, inputs 5, 6, and 7, brackets are places around the destination line number. Also in input 6, the greater than symbol is flipped and the expression on each side are swapped. All boolean expressions receive brackets around them. 