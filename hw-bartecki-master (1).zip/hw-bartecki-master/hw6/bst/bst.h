#ifndef BST_H
#define BST_H

#include <iostream>
#include <exception>
#include <cstdlib>
#include <utility>


/**
* A templated class for a Node in a search tree. The getters for parent/left/right are virtual so that they
* can be overridden for future kinds of search trees, such as Red Black trees, Splay trees, and AVL trees.
*/
template <typename Key, typename Value>
class Node
{
public:
	Node(const Key& key, const Value& value, Node<Key, Value>* parent);
	virtual ~Node();

	const std::pair<Key, Value>& getItem() const;
	std::pair<Key, Value>& getItem();
	const Key& getKey() const;
	const Value& getValue() const;
	Key& getKey();
	Value& getValue();

	virtual Node<Key, Value>* getParent() const;
	virtual Node<Key, Value>* getLeft() const;
	virtual Node<Key, Value>* getRight() const;

	void setParent(Node<Key, Value>* parent);
	void setLeft(Node<Key, Value>* left);
	void setRight(Node<Key, Value>* right);
	void setValue(const Value &value);

protected:
	std::pair<Key, Value> mItem;
	Node<Key, Value>* mParent;
	Node<Key, Value>* mLeft;
	Node<Key, Value>* mRight;
};

/* 
	-----------------------------------------
	Begin implementations for the Node class.
	-----------------------------------------
*/

/**
* Explicit constructor for a node.
*/
template<typename Key, typename Value>
Node<Key, Value>::Node(const Key& key, const Value& value, Node<Key, Value>* parent)
	: mItem(key, value), mParent(parent), mLeft(NULL), mRight(NULL)
{

}

/**
* Destructor, which does not need to do anything since the pointers inside of a node
* are only used as references to existing nodes. The nodes pointed to by parent/left/right
* are freed within the destructor in the BinarySearchTree.
*/
template<typename Key, typename Value>
Node<Key, Value>::~Node()
{

}

/**
* A const getter for the item.
*/
template<typename Key, typename Value>
const std::pair<Key, Value>& Node<Key, Value>::getItem() const
{
	return mItem;
}

/**
* A non-const getter for the item.
*/
template<typename Key, typename Value>
std::pair<Key, Value>& Node<Key, Value>::getItem()
{
	return mItem;
}

/**
* A const getter for the key.
*/
template<typename Key, typename Value>
const Key& Node<Key, Value>::getKey() const
{
	return mItem.first;
}

/**
* A const getter for the value.
*/
template<typename Key, typename Value>
const Value& Node<Key, Value>::getValue() const
{
	return mItem.second;
}

/**
* A non-const getter for the key.
*/
template<typename Key, typename Value>
Key& Node<Key, Value>::getKey()
{
	return mItem.first;
}

/**
* A non-const getter for the value.
*/
template<typename Key, typename Value>
Value& Node<Key, Value>::getValue()
{
	return mItem.second;
}

/**
* An implementation of the virtual function for retreiving the parent.
*/
template<typename Key, typename Value>
Node<Key, Value>* Node<Key, Value>::getParent() const
{
	return mParent;
}

/**
* An implementation of the virtual function for retreiving the left child.
*/
template<typename Key, typename Value>
Node<Key, Value>* Node<Key, Value>::getLeft() const
{
	return mLeft;
}

/**
* An implementation of the virtual function for retreiving the right child.
*/
template<typename Key, typename Value>
Node<Key, Value>* Node<Key, Value>::getRight() const
{
	return mRight;
}

/**
* A setter for setting the parent of a node.
*/
template<typename Key, typename Value>
void Node<Key, Value>::setParent(Node<Key, Value>* parent)
{
	mParent = parent;
}

/**
* A setter for setting the left child of a node.
*/
template<typename Key, typename Value>
void Node<Key, Value>::setLeft(Node<Key, Value>* left)
{
	mLeft = left;
}

/**
* A setter for setting the right child of a node.
*/
template<typename Key, typename Value>
void Node<Key, Value>::setRight(Node<Key, Value>* right)
{
	mRight = right;
}

/**
* A setter for the value of a node.
*/
template<typename Key, typename Value>
void Node<Key, Value>::setValue(const Value& value)
{
	mItem.second = value;
}

/* 
	---------------------------------------
	End implementations for the Node class.
	---------------------------------------
*/

/**
* A templated unbalanced binary search tree.
*/
template <typename Key, typename Value>
class BinarySearchTree
{
public:
	BinarySearchTree();
	~BinarySearchTree();

	virtual void insert(const std::pair<Key, Value>& keyValuePair);
	void clear();
	void print() const;

public:
	/**
	* An internal iterator class for traversing the contents of the BST.
	*/
	class iterator
	{
	public:
		iterator(Node<Key,Value>* ptr);
		iterator();

		std::pair<Key,Value>& operator*();
		std::pair<Key,Value>* operator->();

		bool operator==(const iterator& rhs) const;
		bool operator!=(const iterator& rhs) const;
		iterator& operator=(const iterator& rhs);

		iterator& operator++();

	protected:
		Node<Key, Value>* mCurrent;
	};

public:
	iterator begin();
	iterator end();
	iterator find(const Key& key) const;

protected:
	Node<Key, Value>* internalFind(const Key& key) const;
	Node<Key, Value>* getSmallestNode() const;
	void printRoot (Node<Key, Value>* root) const;
	void remove(Node<Key, Value>* removed, Node<Key, Value>* successor);
	void removeAllNodes(Node<Key, Value>* removed);
	Node<Key, Value>* internalFindHelper(const Key& key, Node<Key, Value>* node) const;
	void swap(Node<Key, Value>* removing, Node<Key, Value>* successor);
	Node<Key, Value>* getSuccessor(Node<Key, Value>* start);
	void zigzig(Node<Key, Value>*& z, Node<Key, Value>*& y, Node<Key, Value>*&x);
	void zigzag(Node<Key, Value>*& z, Node<Key, Value>*& y, Node<Key, Value>*&x);


protected:
	Node<Key, Value>* mRoot;

};

/* 
	---------------------------------------------------------------
	Begin implementations for the BinarySearchTree::iterator class.
	---------------------------------------------------------------
*/ 

/**
* Explicit constructor that initializes an iterator with a given node pointer.
*/
template<typename Key, typename Value>
BinarySearchTree<Key, Value>::iterator::iterator(Node<Key,Value>* ptr)
	: mCurrent(ptr)
{

}

/**
* A default constructor that initializes the iterator to NULL.
*/
template<typename Key, typename Value>
BinarySearchTree<Key, Value>::iterator::iterator()
	: mCurrent(NULL)
{

}

/**
* Provides access to the item.
*/
template<typename Key, typename Value>
std::pair<Key, Value>& BinarySearchTree<Key, Value>::iterator::operator*()
{
	return mCurrent->getItem(); 
}

/**
* Provides access to the address of the item.
*/
template<typename Key, typename Value>
std::pair<Key, Value>* BinarySearchTree<Key, Value>::iterator::operator->()
{
	return &(mCurrent->getItem());
}

/**
* Checks if 'this' iterator's internals have the same value
* as 'rhs'
*/
template<typename Key, typename Value>
bool BinarySearchTree<Key, Value>::iterator::operator==(const BinarySearchTree<Key, Value>::iterator& rhs) const
{
	return this->mCurrent == rhs.mCurrent;
}

/**
* Checks if 'this' iterator's internals have a different value
* as 'rhs'
*/
template<typename Key, typename Value>
bool BinarySearchTree<Key, Value>::iterator::operator!=(const BinarySearchTree<Key, Value>::iterator& rhs) const
{
	return this->mCurrent != rhs.mCurrent;
}

/**
* Sets one iterator equal to another iterator.
*/
template<typename Key, typename Value>
typename BinarySearchTree<Key, Value>::iterator &BinarySearchTree<Key, Value>::iterator::operator=(const BinarySearchTree<Key, Value>::iterator& rhs)
{
	this->mCurrent = rhs.mCurrent;
	return *this;
}

/**
* Advances the iterator's location using an in-order traversal.
*/
template<typename Key, typename Value>
typename BinarySearchTree<Key, Value>::iterator& BinarySearchTree<Key, Value>::iterator::operator++()
{
	if(mCurrent->getRight() != NULL)
	{
		mCurrent = mCurrent->getRight();
		while(mCurrent->getLeft() != NULL)
		{
			mCurrent = mCurrent->getLeft();
		}
	}
	else if(mCurrent->getRight() == NULL)
	{
		Node<Key, Value>* parent = mCurrent->getParent();
		while(parent != NULL && mCurrent == parent->getRight())
		{
			mCurrent = parent;
			parent = parent->getParent();
		}
		mCurrent = parent;
	}
	return *this;
}

/* 
	-------------------------------------------------------------
	End implementations for the BinarySearchTree::iterator class.
	-------------------------------------------------------------
*/

/* 
	-----------------------------------------------------
	Begin implementations for the BinarySearchTree class.
	-----------------------------------------------------
*/

/**
* Default constructor for a BinarySearchTree, which sets the root to NULL.
*/
template<typename Key, typename Value>
BinarySearchTree<Key, Value>::BinarySearchTree()
{
	mRoot = NULL;
}

template<typename Key, typename Value>
BinarySearchTree<Key, Value>::~BinarySearchTree()
{
	clear();
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::print() const
{
	printRoot(mRoot);
	std::cout << "\n";
}

/**
* Returns an iterator to the "smallest" item in the tree
*/
template<typename Key, typename Value>
typename BinarySearchTree<Key, Value>::iterator BinarySearchTree<Key, Value>::begin() 
{
	BinarySearchTree<Key, Value>::iterator begin(getSmallestNode());
	return begin;
}

/**
* Returns an iterator whose value means INVALID
*/
template<typename Key, typename Value>
typename BinarySearchTree<Key, Value>::iterator BinarySearchTree<Key, Value>::end() 
{
	BinarySearchTree<Key, Value>::iterator end(NULL);
	return end;
}

/**
* Returns an iterator to the item with the given key, k
* or the end iterator if k does not exist in the tree
*/
template<typename Key, typename Value>
typename BinarySearchTree<Key, Value>::iterator BinarySearchTree<Key, Value>::find(const Key& key) const
{
	Node<Key, Value>* curr = internalFind(key);
	BinarySearchTree<Key, Value>::iterator it(curr);
	return it;
}

/**
* An insert method to insert into a Binary Search Tree. The tree will not remain balanced when
* inserting.
*/
template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::insert(const std::pair<Key, Value>& keyValuePair)
{
	//If first node
	if(mRoot == NULL)
	{
		mRoot = new Node<Key, Value>(keyValuePair.first, keyValuePair.second, NULL);
	}
	else
	{
		Node<Key, Value>* duplicate = internalFind(keyValuePair.first);
		if(duplicate != NULL)
		{
			duplicate->setValue(keyValuePair.second);
		}
		else
		{
			//Finds where node should be inserted
			Node<Key, Value>* comparer = mRoot;
			Node<Key, Value>* setter = comparer;
			while(comparer != NULL)
			{
				if(comparer->getKey() > keyValuePair.first)
				{
					setter = comparer;
					comparer = comparer->getLeft();
				}
				else
				{
					setter = comparer;
					comparer = comparer->getRight();
				}
			}
			Node<Key, Value>* newnode = new Node<Key, Value>(keyValuePair.first, keyValuePair.second, setter);
			//Checks which side node inserted on
			if(setter->getKey() > keyValuePair.first)
			{
				setter->setLeft(newnode);
			}
			else
			{
				setter->setRight(newnode);
			}
		}
	}
}

/**
* A method to remove all contents of the tree and reset the values in the tree
* for use again.
*/
template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::clear()
{
	removeAllNodes(mRoot);
	mRoot = NULL;
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::removeAllNodes(Node<Key, Value>* removed)
{
	if(removed != NULL)
	{
		removeAllNodes(removed->getLeft());
		removeAllNodes(removed->getRight());
		delete removed;
	}
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::remove(Node<Key, Value>* removed, Node<Key, Value>* successor)
{
	//Resets root
	if(removed == mRoot)
	{
		mRoot = successor;
	}

	//Swap with successor
	if(removed != successor && successor != NULL)
	{
		swap(removed, successor);
	}

	//If leaf node just remove and reset parent
	if(removed->getRight() == NULL && removed->getLeft() == NULL)
	{
		if(removed->getParent() != NULL)
		{
			if(successor->getKey() >= removed->getParent()->getKey())
			{
				removed->getParent()->setRight(NULL);
			}
			else
			{
				removed->getParent()->setLeft(NULL);
			}
		}
	}
	//Otherwise has one child so adopt
	else
	{
		removed->getRight()->setParent(removed->getParent());
		removed->getParent()->setRight(removed->getRight());
	}
}

//Finds successor of any given node
template<typename Key, typename Value>
Node<Key, Value>* BinarySearchTree<Key, Value>::getSuccessor(Node<Key, Value>* removing)
{
	Node<Key, Value>* successor;
	//Checks right then left first
	if(removing->getRight() != NULL)
	{
		successor = removing->getRight();
		while(successor->getLeft() != NULL)
		{
			successor = successor->getLeft();
		}
		
		return successor;
	}
	//Otherwise checks parent
	else if(removing->getParent() != NULL)
	{
		if(removing->getKey() < removing->getParent()->getKey())
		{
			successor = removing->getParent();
			return successor;
		}
		else if(removing->getParent()->getParent() != NULL && removing->getKey() < removing->getParent()->getParent()->getKey())
		{
			successor = removing->getParent()->getParent();
			return successor;
		}
	}
	return NULL;
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::swap(Node<Key, Value>* removing, Node<Key, Value>* successor)
{
	//Completely swaps two nodes and anything pointing to them
	if(removing->getLeft() != NULL)
	{
		removing->getLeft()->setParent(successor);
	}
	if(removing->getRight() != NULL && removing->getRight() != successor)
	{
		removing->getRight()->setParent(successor);
	}
	if(removing->getParent() != NULL && removing->getParent() != successor)
	{
		if(removing->getKey() < removing->getParent()->getKey())
		{
			removing->getParent()->setLeft(successor);
		}
		else
		{
			removing->getParent()->setRight(successor);
		}
	}
	if(successor->getLeft() != NULL && successor->getLeft() != removing)
	{
		successor->getLeft()->setParent(removing);
	}
	if(successor->getRight() != NULL && successor->getRight() != removing)
	{
		successor->getRight()->setParent(removing);
	}
	if(successor->getParent() != NULL && successor->getParent() != removing)
	{
		if(successor->getKey() < successor->getParent()->getKey())
		{
			successor->getParent()->setLeft(removing);
		}
		else
		{
			successor->getParent()->setRight(removing);
		}
	}

	Node<Key, Value>* temp_parent = removing->getParent();
	Node<Key, Value>* temp_left = removing->getLeft();
	Node<Key, Value>* temp_right = removing->getRight();
	if(successor->getParent() != removing)
	{
		removing->setParent(successor->getParent());
	}
	else
	{
		removing->setParent(successor);
	}

	if(successor->getLeft() != removing)
	{
		removing->setLeft(successor->getLeft());
	}
	else
	{
		removing->setLeft(successor);
	}

	if(successor->getRight() != removing)
	{
		removing->setRight(successor->getRight());
	}
	else
	{
		removing->setRight(successor);
	}

	if(temp_parent != successor)
	{
		successor->setParent(temp_parent);
	}
	else
	{
		successor->setParent(removing);
	}

	if(temp_left != successor)
	{
		successor->setLeft(temp_left);
	}
	else
	{
		successor->setLeft(removing);
	}

	if(temp_right != successor)
	{
		successor->setRight(temp_right);
	}
	else
	{
		successor->setRight(removing);
	}
}

/**
* A helper function to find the smallest node in the tree.
*/
template<typename Key, typename Value>
Node<Key, Value>* BinarySearchTree<Key, Value>::getSmallestNode() const
{
	Node<Key, Value>* smallest = mRoot;
	if(smallest != NULL)
	{
		while(smallest->getLeft() != NULL)
		{
			smallest = smallest->getLeft();
		}
	}
	return smallest;
}

/**
* Helper function to find a node with given key, k and
* return a pointer to it or NULL if no item with that key
* exists
*/
template<typename Key, typename Value>
Node<Key, Value>* BinarySearchTree<Key, Value>::internalFind(const Key& key) const
{
	return internalFindHelper(key, mRoot);
}

template<typename Key, typename Value>
Node<Key, Value>* BinarySearchTree<Key, Value>::internalFindHelper(const Key& key, Node<Key, Value>* node) const
{
	if(node == NULL)
	{
		return NULL;
	}
	if(node->getKey() == key)
	{
		return node;
	}

	if(key < node->getKey())
	{
		return internalFindHelper(key, node->getLeft());
	}
	else
	{
		return internalFindHelper(key, node->getRight());
	}
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::zigzig(Node<Key, Value>*& z, Node<Key, Value>*& y, Node<Key, Value>*&x)
{
	//Performs a single rotation left or right
	if(x == y->getRight() && y == z->getRight())
	{
		if(z->getParent() != NULL)
		{
			if(z->getParent()->getKey() > z->getKey())
			{
				z->getParent()->setLeft(y);
			}
			else
			{
				z->getParent()->setRight(y);
			}
		}
		if(y->getLeft() != NULL)
		{
			y->getLeft()->setParent(z);
		}
		y->setParent(z->getParent());
		z->setRight(y->getLeft());
		z->setParent(y);
		y->setLeft(z);

	}
	else
	{
		if(z->getParent() != NULL)
		{
			if(z->getParent()->getKey() > z->getKey())
			{
				z->getParent()->setLeft(y);
			}
			else
			{
				z->getParent()->setRight(y);
			}
		}
		if(y->getRight() != NULL)
		{
			y->getRight()->setParent(z);
		}
		y->setParent(z->getParent());
		z->setLeft(y->getRight());
		z->setParent(y);
		y->setRight(z);
	}
}

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::zigzag(Node<Key, Value>*& z, Node<Key, Value>*& y, Node<Key, Value>*&x)
{
	//Performs a double rotation left or right
	if(x == y->getRight() && y == z->getLeft())
	{
		if(z->getParent() != NULL)
		{
			if(z->getParent()->getKey() > z->getKey())
			{
				z->getParent()->setLeft(x);
			}
			else
			{
				z->getParent()->setRight(x);
			}
		}
		if(x->getLeft() != NULL)
		{
			x->getLeft()->setParent(y);
		}
		if(x->getRight() != NULL)
		{
			x->getRight()->setParent(z);
		}
		x->setParent(z->getParent());
		y->setRight(x->getLeft());
		z->setLeft(x->getRight());
		x->setLeft(y);
		x->setRight(z);
		y->setParent(x);
		z->setParent(x);
	}
	else
	{
		if(z->getParent() != NULL)
		{
			if(z->getParent()->getKey() > z->getKey())
			{
				z->getParent()->setLeft(x);
			}
			else
			{
				z->getParent()->setRight(x);
			}
		}
		if(x->getLeft() != NULL)
		{
			x->getLeft()->setParent(z);
		}
		if(x->getRight() != NULL)
		{
			x->getRight()->setParent(y);
		}
		x->setParent(z->getParent());
		y->setLeft(x->getRight());
		z->setRight(x->getLeft());
		x->setLeft(z);
		x->setRight(y);
		y->setParent(x);
		z->setParent(x);
	}
}




/**
* Helper function to print the tree's contents
*/

template<typename Key, typename Value>
void BinarySearchTree<Key, Value>::printRoot (Node<Key, Value>* root) const
{
	if (root != NULL)
	{
		std::cout << "[";
		printRoot (root->getLeft());
		std::cout << " (" << root->getKey() << ", " << root->getValue() << ") ";
		printRoot (root->getRight());
		std::cout << "]";
	}
}

/* 
	---------------------------------------------------
	End implementations for the BinarySearchTree class.
	---------------------------------------------------
*/

#endif
