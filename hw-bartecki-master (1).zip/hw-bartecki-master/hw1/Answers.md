1. Course Policies
(a) 1, 4 
(b) 2, 3, 4
(c) 2, 3, 4, 5
(d) 2
(e) 2, 3

2. Git Quiz
(a) 3
(b) 1, 2
(c) 1. git add hw1q2b.cpp
    2. "Code debugged and exceptions added" commit 1202fab2f9a9f9784c548d890820812bded0b73f
    "All comments added" commit 98bf8d1d4c4d89c285ae8d9fabde34b661237f7d
    "file_reverse updated" commit ddbdec57ddf48af7b198c954d308cdeb9c3c88d4
(d) it will ask what message we would like to commit with
(e) git clone git@github.com:usc-csci104-fall2019/hw-bartecki.git

3. More Git Questions 
(a) tracked and unmodified
(b) README.md is tracked and modified while fun_problems.txt is untracked
(c) both are tracked and staged 
(d) both are tracked and modified
(e) README.md is tracked and staged, fun_problem.txt is tracked and unmodified. The text file is empty because checkout converted it to its last commit in which case it was empty. 
(f) README.md is tracked but both staged and unstaged. Since the file was added in the previous step, it is staged to be committed. However, you modify the file again in this step and never update the changes with an additional add statement. 